//=========================================================================
// 7-Stage RISCV Control Unit
//=========================================================================

`ifndef RISCV_CORE_CTRL_V
`define RISCV_CORE_CTRL_V

`include "riscvssc_part2-InstMsg.v"
`include "riscvssc_part2-CoreScoreboard.v"

module riscv_CoreCtrl
(
  input             clk,
  input             reset,

  // Instruction Memory Port 0 (fetches pc)
  output            imemreq0_val,
  input             imemreq0_rdy,
  input      [31:0] imemresp0_msg_data,
  input             imemresp0_val,
  output            imemresp0_rdy,

  // Instruction Memory Port 1 (fetches pc+4)
  output            imemreq1_val,
  input             imemreq1_rdy,
  input      [31:0] imemresp1_msg_data,
  input             imemresp1_val,
  output            imemresp1_rdy,

  // Instruction Fetch Sequencing (ctrl->core)

  output reg        imem_initial_fetch_Fhl,
  output            imemreq_start_Fhl,
  output reg [ 1:0] imemreq_pending_Fhl,

  // Data Memory Port

  output            dmemreq_msg_rw,
  output     [ 1:0] dmemreq_msg_len,
  output            dmemreq_val,
  input             dmemreq_rdy,
  input             dmemresp_val,
  output            dmemresp_rdy,

  // Controls Signals (ctrl->dpath)

  output     [ 2:0] pc_mux_sel_Phl,       // widen for branch prediction
  output reg        steering_mux_sel_Dhl,
  output reg [ 3:0] opA0_byp_mux_sel_Dhl,
  output reg [ 1:0] opA0_mux_sel_Dhl,
  output reg [ 3:0] opA1_byp_mux_sel_Dhl,
  output reg [ 2:0] opA1_mux_sel_Dhl,
  output reg [ 3:0] opB0_byp_mux_sel_Dhl,
  output reg [ 1:0] opB0_mux_sel_Dhl,
  output reg [ 3:0] opB1_byp_mux_sel_Dhl,
  output reg [ 2:0] opB1_mux_sel_Dhl,
  output reg [31:0] instA_Dhl,
  output reg [31:0] instB_Dhl,
  output reg [ 3:0] aluA_fn_X0hl,
  output reg [ 3:0] aluB_fn_X0hl,
  output reg [ 2:0] muldivreq_msg_fn_Dhl,
  output            muldivreq_val,
  output            muldivresp_rdy,
  output reg [ 2:0] dmemresp_mux_sel_X1hl,
  output reg        muldiv_mux_sel_X3hl,
  output reg        execute_mux_sel_X3hl,
  output reg        memex_mux_sel_X1hl,
  output            rfA_wen_out_Whl,
  output reg [ 4:0] rfA_waddr_Whl,
  output            rfB_wen_out_Whl,
  output reg [ 4:0] rfB_waddr_Whl,
  output            squash_Fhl,
  output            stall_Fhl,
  output            stall_Dhl,
  output            stall_X0hl,
  output            stall_X1hl,
  output            stall_X2hl,
  output            stall_X3hl,
  output            stall_Whl,

  // Control Signals (dpath->ctrl)

  input             branch_cond_eq_X0hl,
  input             branch_cond_ne_X0hl,
  input             branch_cond_lt_X0hl,
  input             branch_cond_ltu_X0hl,
  input             branch_cond_ge_X0hl,
  input             branch_cond_geu_X0hl,
  output reg        lateA0_X0hl,      // FUA operand 0 in X0: use the mul result in X3
  output reg        lateA1_X0hl,      // FUA operand 1
  output reg        lateWd_X0hl,      // FUA store data
  output reg        lateB0_X0hl,      // FUB operand 0
  output reg        lateB1_X0hl,      // FUB operand 1
  input             btb_taken0_Fhl,   // BTB: slot 0 of the pair in F predicted taken
  input             btb_taken1_Fhl,   // BTB: slot 1 of the pair in F predicted taken
  input             btb_match_br_Dhl, // BTB target used == branch_targ_Dhl
  input             btb_match_j_Dhl,  // BTB target used == jump_targ_Dhl
  output            btb_br_upd_X0hl,  // update BTB with the branch in X0
  output            btb_br_taken_X0hl,// its outcome
  output            btb_jal_fill_Dhl, // fill BTB with the jal leaving D
  input      [31:0] proc2csr_data_Whl,

  // CSR Status

  output reg [31:0] csr_status
);

  //----------------------------------------------------------------------
  // PC Stage
  //----------------------------------------------------------------------

  // PC Mux Select

  // Priority, most urgent first:
  //   1. misprediction in X0 (the branch has already issued, so it is not
  //      gated with issue_A): should have been taken -> branch target,
  //      should not have been taken -> the branch's fall-through PC
  //   2. redirect from D, only if the instruction in A issues: a jump that
  //      F did not already redirect to the same target
  //   3. D undoes a wrong F guess -> the D pair's pc+8
  //   4. F guess: BTB hit and predicted taken -> BTB target
  //   5. otherwise the next pair
  // A correctly predicted taken branch in X0 does not redirect again.

  assign pc_mux_sel_Phl
    = bp_miss_taken_X0hl            ? pmx_b
    : bp_miss_nottaken_X0hl         ? pmx_f
    : d_jump_redir_Dhl              ? {1'b0, pc_mux_sel_Dhl}
    : f_corr_Dhl                    ? pmx_seq
    : ( f_pred0_Fhl || f_pred1_Fhl )? pmx_btb
    :                                 pmx_p;

  // Dummy Squash Signal

  wire squash_Phl = 1'b0;

  // Stall in PC if F is stalled

  wire stall_Phl = stall_Fhl;

  // Next bubble bit

  wire bubble_next_Phl = ( squash_Phl || stall_Phl );

  //----------------------------------------------------------------------
  // F <- P
  //----------------------------------------------------------------------

  reg bubble_Fhl;

  always @ ( posedge clk ) begin
    // Only pipeline the bubble bit if the next stage is not stalled
    if ( reset ) begin
      bubble_Fhl <= 1'b0;
    end
    else if( !stall_Fhl ) begin
      bubble_Fhl <= bubble_next_Phl;
    end
  end

  //----------------------------------------------------------------------
  // Fetch Stage: Instruction Memory Request
  //----------------------------------------------------------------------
  // Both fetch ports are launched together and always read the pair
  // { pc, pc+4 }. A request that was presented but not accepted stays
  // pending, and req_val must remain asserted until the memory takes it.

  reg imem_inflight_Fhl;
  reg imem_abandoned_Fhl;

  wire [1:0] imemreq_val_Fhl = { imemreq1_val, imemreq0_val };
  wire [1:0] imemreq_rdy_Fhl = { imemreq1_rdy, imemreq0_rdy };

  always @ ( posedge clk ) begin
    if ( reset ) begin
      imemreq_pending_Fhl <= 2'b00;
    end
    else begin
      imemreq_pending_Fhl <= imemreq_val_Fhl & ~imemreq_rdy_Fhl;
    end
  end

  assign imemreq0_val = ( imemreq_pending_Fhl[0] || imemreq_start_Fhl );
  assign imemreq1_val = ( imemreq_pending_Fhl[1] || imemreq_start_Fhl );

  // The first fetch after reset reads the reset vector rather than the PC

  always @ ( posedge clk ) begin
    if ( reset ) begin
      imem_initial_fetch_Fhl <= 1'b1;
    end
    else if ( imemreq_start_Fhl ) begin
      imem_initial_fetch_Fhl <= 1'b0;
    end
  end

  //----------------------------------------------------------------------
  // Fetch Stage: Instruction Memory Response
  //----------------------------------------------------------------------

  reg        imemresp0_buf_val_Fhl;
  reg [31:0] imemresp0_buf_data_Fhl;
  reg        imemresp1_buf_val_Fhl;
  reg [31:0] imemresp1_buf_data_Fhl;

  assign imemresp0_rdy = !imemresp0_buf_val_Fhl;
  assign imemresp1_rdy = !imemresp1_buf_val_Fhl;

  // An instruction is available if it is buffered or arriving right now

  wire imem_inst0_val_Fhl = ( imemresp0_buf_val_Fhl || imemresp0_val );
  wire imem_inst1_val_Fhl = ( imemresp1_buf_val_Fhl || imemresp1_val );

  wire [31:0] imem_inst0_Fhl
    = imemresp0_buf_val_Fhl ? imemresp0_buf_data_Fhl : imemresp0_msg_data;
  wire [31:0] imem_inst1_Fhl
    = imemresp1_buf_val_Fhl ? imemresp1_buf_data_Fhl : imemresp1_msg_data;

  // The pair is complete, and handed to D when D can accept it

  wire imem_pair_val_Fhl      = ( imem_inst0_val_Fhl && imem_inst1_val_Fhl );
  wire imem_pair_consumed_Fhl = ( imem_pair_val_Fhl && !stall_Dhl );

  // Port 0 response buffer

  always @ ( posedge clk ) begin
    if ( reset ) begin
      imemresp0_buf_val_Fhl  <= 1'b0;
      imemresp0_buf_data_Fhl <= 32'b0;
    end
    else if ( imem_pair_consumed_Fhl ) begin
      imemresp0_buf_val_Fhl  <= 1'b0;
      imemresp0_buf_data_Fhl <= 32'b0;
    end
    else if ( imemresp0_val && imemresp0_rdy ) begin
      imemresp0_buf_val_Fhl  <= 1'b1;
      imemresp0_buf_data_Fhl <= imemresp0_msg_data;
    end
  end

  // Port 1 response buffer

  always @ ( posedge clk ) begin
    if ( reset ) begin
      imemresp1_buf_val_Fhl  <= 1'b0;
      imemresp1_buf_data_Fhl <= 32'b0;
    end
    else if ( imem_pair_consumed_Fhl ) begin
      imemresp1_buf_val_Fhl  <= 1'b0;
      imemresp1_buf_data_Fhl <= 32'b0;
    end
    else if ( imemresp1_val && imemresp1_rdy ) begin
      imemresp1_buf_val_Fhl  <= 1'b1;
      imemresp1_buf_data_Fhl <= imemresp1_msg_data;
    end
  end

  //----------------------------------------------------------------------
  // Fetch Stage: Fetch Sequencing
  //----------------------------------------------------------------------


  always @ ( posedge clk ) begin
    if ( reset ) begin
      imem_inflight_Fhl <= 1'b0;
    end
    else if ( imemreq_start_Fhl ) begin
      imem_inflight_Fhl <= 1'b1;
    end
    else if ( imem_pair_consumed_Fhl ) begin
      imem_inflight_Fhl <= 1'b0;
    end
  end

  assign imemreq_start_Fhl
    = !stall_Dhl && ( !imem_inflight_Fhl || imem_pair_consumed_Fhl );


  always @ ( posedge clk ) begin
    if ( reset ) begin
      imem_abandoned_Fhl <= 1'b0;
    end
    else if ( imem_pair_consumed_Fhl ) begin
      imem_abandoned_Fhl <= 1'b0;
    end
    else if ( squash_Fhl && imem_inflight_Fhl ) begin
      imem_abandoned_Fhl <= 1'b1;
    end
  end

  //----------------------------------------------------------------------
  // Fetch Stage: Squash and Stall Logic
  //----------------------------------------------------------------------

  // Is the current stage valid?

  wire inst_val_Fhl = ( !bubble_Fhl && !squash_Fhl );

  // Squash F when D redirects (a jump, or a predicted-taken branch
  // that issues), or when X0 detects a misprediction. A correctly predicted
  // branch in X0 does not squash.

  assign squash_Fhl
    = d_jump_redir_Dhl || f_corr_Dhl || bp_miss_X0hl;

  // F guess: only for a real pair in F (not a bubble, not squashed, not an
  // abandoned fetch). Slot 0 wins; slot 1 is then on the wrong path.
  wire f_guess_ok_Fhl = !bubble_Fhl && !squash_Fhl && !imem_abandoned_Fhl;
  wire f_pred0_Fhl    = f_guess_ok_Fhl &&  btb_taken0_Fhl;
  wire f_pred1_Fhl    = f_guess_ok_Fhl && !btb_taken0_Fhl && btb_taken1_Fhl;

  // Stall in F if D is stalled or the fetch pair has not fully returned

  assign stall_Fhl = ( stall_Dhl || !imem_pair_val_Fhl );

  // Next bubble bit

  wire bubble_sel_Fhl  = ( squash_Fhl || stall_Fhl || imem_abandoned_Fhl );
  wire bubble_next_Fhl = ( !bubble_sel_Fhl ) ? bubble_Fhl
                       : ( bubble_sel_Fhl )  ? 1'b1
                       :                       1'bx;

  //----------------------------------------------------------------------
  // D <- F
  //----------------------------------------------------------------------

  reg [31:0] ir0_Dhl;
  reg [31:0] ir1_Dhl;
  reg        bubble_Dhl;
  reg        f_pred0_Dhl;
  reg        f_pred1_Dhl;

  always @ ( posedge clk ) begin
    if ( reset ) begin
      bubble_Dhl <= 1'b1;
      f_pred0_Dhl <= 1'b0;
      f_pred1_Dhl <= 1'b0;
    end
    else if( !stall_Dhl ) begin
      ir0_Dhl    <= imem_inst0_Fhl;
      ir1_Dhl    <= imem_inst1_Fhl;
      f_pred0_Dhl <= f_pred0_Fhl;
      f_pred1_Dhl <= f_pred1_Fhl;
      bubble_Dhl <= bubble_next_Fhl;
    end
  end

  //----------------------------------------------------------------------
  // Decode Stage: Constants
  //----------------------------------------------------------------------

  // Generic Parameters

  localparam n = 1'd0;
  localparam y = 1'd1;

  // Register specifiers

  localparam rx = 5'bx;
  localparam r0 = 5'd0;

  // Branch Type

  localparam br_x    = 3'bx;
  localparam br_none = 3'd0;
  localparam br_beq  = 3'd1;
  localparam br_bne  = 3'd2;
  localparam br_blt  = 3'd3;
  localparam br_bltu = 3'd4;
  localparam br_bge  = 3'd5;
  localparam br_bgeu = 3'd6;

  // PC Mux Select

  // Original pm_* stay 2 bits: the cs0/cs1 tables concatenate them into the 2-bit
  // RISCV_INST_MSG_PC_SEL field, so widening them would shift every field.

  localparam pm_x   = 2'bx;  // Don't care
  localparam pm_p   = 2'd0;  // Use pc+4
  localparam pm_b   = 2'd1;  // Use branch address
  localparam pm_j   = 2'd2;  // Use jump address
  localparam pm_r   = 2'd3;  // Use jump register

  // Add 3-bit PC mux select to the datapath: 0-3 are pm_* zero-extended,
  // 4 and 5 are the two new inputs added for branch prediction.

  localparam pmx_p  = 3'd0;  // Use pc+8 (next pair)
  localparam pmx_b  = 3'd1;  // Use branch address from X0
  localparam pmx_f  = 3'd5;  // Use fall-through of the branch in X0
  localparam pmx_btb = 3'd6; // Use BTB target (F guess)
  localparam pmx_seq = 3'd7; // Use the D pair's pc+8 (D undoes F's guess)

  // Operand 0 Bypass Mux Select

  localparam am_r0    = 4'd0; // Use rdata0
  localparam am_AX0_byp = 4'd1; // Bypass from X0
  localparam am_AX1_byp = 4'd2; // Bypass from X1
  localparam am_AX2_byp = 4'd3; // Bypass from X2
  localparam am_AX3_byp = 4'd4; // Bypass from X3
  localparam am_AW_byp = 4'd5; // Bypass from W
  localparam am_BX0_byp = 4'd6; // Bypass from X0
  localparam am_BX1_byp = 4'd7; // Bypass from X1
  localparam am_BX2_byp = 4'd8; // Bypass from X2
  localparam am_BX3_byp = 4'd9; // Bypass from X3
  localparam am_BW_byp = 4'd10; // Bypass from W

  // Operand 0 Mux Select

  localparam am_x     = 2'bx;
  localparam am_rdat  = 2'd0; // Use output of bypass mux for rs1
  localparam am_pc    = 2'd1; // Use current PC
  localparam am_pc4   = 2'd2; // Use PC + 4
  localparam am_0     = 2'd3; // Use constant 0

  // Operand 1 Bypass Mux Select

  localparam bm_r1    = 4'd0; // Use rdata1
  localparam bm_AX0_byp = 4'd1; // Bypass from X0
  localparam bm_AX1_byp = 4'd2; // Bypass from X1
  localparam bm_AX2_byp = 4'd3; // Bypass from X2
  localparam bm_AX3_byp = 4'd4; // Bypass from X3
  localparam bm_AW_byp = 4'd5; // Bypass from W
  localparam bm_BX0_byp = 4'd6; // Bypass from X0
  localparam bm_BX1_byp = 4'd7; // Bypass from X1
  localparam bm_BX2_byp = 4'd8; // Bypass from X2
  localparam bm_BX3_byp = 4'd9; // Bypass from X3
  localparam bm_BW_byp = 4'd10; // Bypass from W

  // Operand 1 Mux Select

  localparam bm_x      = 3'bx; // Don't care
  localparam bm_rdat   = 3'd0; // Use output of bypass mux for rs2
  localparam bm_shamt  = 3'd1; // Use shift amount
  localparam bm_imm_u  = 3'd2; // Use U-type immediate
  localparam bm_imm_sb = 3'd3; // Use SB-type immediate
  localparam bm_imm_i  = 3'd4; // Use I-type immediate
  localparam bm_imm_s  = 3'd5; // Use S-type immediate
  localparam bm_0      = 3'd6; // Use constant 0

  // ALU Function

  localparam alu_x    = 4'bx;
  localparam alu_add  = 4'd0;
  localparam alu_sub  = 4'd1;
  localparam alu_sll  = 4'd2;
  localparam alu_or   = 4'd3;
  localparam alu_lt   = 4'd4;
  localparam alu_ltu  = 4'd5;
  localparam alu_and  = 4'd6;
  localparam alu_xor  = 4'd7;
  localparam alu_nor  = 4'd8;
  localparam alu_srl  = 4'd9;
  localparam alu_sra  = 4'd10;

  // Muldiv Function

  localparam md_x    = 3'bx;
  localparam md_mul  = 3'd0;
  localparam md_div  = 3'd1;
  localparam md_divu = 3'd2;
  localparam md_rem  = 3'd3;
  localparam md_remu = 3'd4;

  // MulDiv Mux Select

  localparam mdm_x = 1'bx; // Don't Care
  localparam mdm_l = 1'd0; // Take lower half of 64-bit result, mul/div/divu
  localparam mdm_u = 1'd1; // Take upper half of 64-bit result, rem/remu

  // Execute Mux Select

  localparam em_x   = 1'bx; // Don't Care
  localparam em_alu = 1'd0; // Use ALU output
  localparam em_md  = 1'd1; // Use muldiv output

  // Memory Request Type

  localparam nr = 2'b0; // No request
  localparam ld = 2'd1; // Load
  localparam st = 2'd2; // Store

  // Subword Memop Length

  localparam ml_x  = 2'bx;
  localparam ml_w  = 2'd0;
  localparam ml_b  = 2'd1;
  localparam ml_h  = 2'd2;

  // Memory Response Mux Select

  localparam dmm_x  = 3'bx;
  localparam dmm_w  = 3'd0;
  localparam dmm_b  = 3'd1;
  localparam dmm_bu = 3'd2;
  localparam dmm_h  = 3'd3;
  localparam dmm_hu = 3'd4;

  // Writeback Mux 1

  localparam wm_x   = 1'bx; // Don't care
  localparam wm_alu = 1'd0; // Use ALU output
  localparam wm_mem = 1'd1; // Use data memory response

  //----------------------------------------------------------------------
  // Decode Stage: Logic
  //----------------------------------------------------------------------

  // Is the current stage valid?

  wire inst_val_Dhl = ( !bubble_Dhl && !squash_Dhl );

  // Parse instruction fields

  wire   [4:0] inst0_rs1_Dhl;
  wire   [4:0] inst0_rs2_Dhl;
  wire   [4:0] inst0_rd_Dhl;

  riscv_InstMsgFromBits inst0_msg_from_bits
  (
    .msg      (ir0_Dhl),
    .opcode   (),
    .rs1      (inst0_rs1_Dhl),
    .rs2      (inst0_rs2_Dhl),
    .rd       (inst0_rd_Dhl),
    .funct3   (),
    .funct7   (),
    .shamt    (),
    .imm_i    (),
    .imm_s    (),
    .imm_sb   (),
    .imm_u    (),
    .imm_uj   ()
  );

  wire   [4:0] inst1_rs1_Dhl;
  wire   [4:0] inst1_rs2_Dhl;
  wire   [4:0] inst1_rd_Dhl;

  riscv_InstMsgFromBits inst1_msg_from_bits
  (
    .msg      (ir1_Dhl),
    .opcode   (),
    .rs1      (inst1_rs1_Dhl),
    .rs2      (inst1_rs2_Dhl),
    .rd       (inst1_rd_Dhl),
    .funct3   (),
    .funct7   (),
    .shamt    (),
    .imm_i    (),
    .imm_s    (),
    .imm_sb   (),
    .imm_u    (),
    .imm_uj   ()
  );

  // Shorten register specifier name for table

  wire [4:0] rs10 = inst0_rs1_Dhl;
  wire [4:0] rs20 = inst0_rs2_Dhl;
  wire [4:0] rd0 = inst0_rd_Dhl;

  wire [4:0] rs11 = inst1_rs1_Dhl;
  wire [4:0] rs21 = inst1_rs2_Dhl;
  wire [4:0] rd1 = inst1_rd_Dhl;

  // Instruction Decode

  localparam cs_sz = 39;
  reg [cs_sz-1:0] cs0;
  reg [cs_sz-1:0] cs1;

  always @ (*) begin

    cs0 = {cs_sz{1'bx}}; // Default to invalid instruction

    casez ( ir0_Dhl )

      //                                j     br       pc      op0      rs1 op1       rs2 alu       md       md md     ex      mem  mem   memresp wb      rf      csr
      //                            val taken type     muxsel  muxsel   en  muxsel    en  fn        fn       en muxsel muxsel  rq   len   muxsel  muxsel  wen wa  wen
      `RISCV_INST_MSG_LUI     :cs0={ y,  n,    br_none, pm_p,   am_0,    n,  bm_imm_u, n,  alu_add,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_AUIPC   :cs0={ y,  n,    br_none, pm_p,   am_pc,   n,  bm_imm_u, n,  alu_add,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };

      `RISCV_INST_MSG_ADDI    :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_add,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_ORI     :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_or,   md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_SLTI    :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_lt,   md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_SLTIU   :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_ltu,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_XORI    :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_xor,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_ANDI    :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_and,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_SLLI    :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_sll,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_SRLI    :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_srl,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_SRAI    :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_sra,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };

      `RISCV_INST_MSG_ADD     :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_add,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_SUB     :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_sub,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_SLL     :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_sll,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_SLT     :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_lt,   md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_SLTU    :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_ltu,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_XOR     :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_xor,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_SRL     :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_srl,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_SRA     :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_sra,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_OR      :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_or,   md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_AND     :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_and,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };

      `RISCV_INST_MSG_LW      :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_add,  md_x,    n, mdm_x, em_x,   ld,  ml_w, dmm_w,  wm_mem, y,  rd0, n   };
      `RISCV_INST_MSG_LB      :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_add,  md_x,    n, mdm_x, em_x,   ld,  ml_b, dmm_b,  wm_mem, y,  rd0, n   };
      `RISCV_INST_MSG_LH      :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_add,  md_x,    n, mdm_x, em_x,   ld,  ml_h, dmm_h,  wm_mem, y,  rd0, n   };
      `RISCV_INST_MSG_LBU     :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_add,  md_x,    n, mdm_x, em_x,   ld,  ml_b, dmm_bu, wm_mem, y,  rd0, n   };
      `RISCV_INST_MSG_LHU     :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_add,  md_x,    n, mdm_x, em_x,   ld,  ml_h, dmm_hu, wm_mem, y,  rd0, n   };
      `RISCV_INST_MSG_SW      :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_s, y,  alu_add,  md_x,    n, mdm_x, em_x,   st,  ml_w, dmm_w,  wm_mem, n,  rx, n   };
      `RISCV_INST_MSG_SB      :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_s, y,  alu_add,  md_x,    n, mdm_x, em_x,   st,  ml_b, dmm_b,  wm_mem, n,  rx, n   };
      `RISCV_INST_MSG_SH      :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_s, y,  alu_add,  md_x,    n, mdm_x, em_x,   st,  ml_h, dmm_h,  wm_mem, n,  rx, n   };

      `RISCV_INST_MSG_JAL     :cs0={ y,  y,    br_none, pm_j,   am_pc4,  n,  bm_0,     n,  alu_add,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_JALR    :cs0={ y,  y,    br_none, pm_r,   am_pc4,  y,  bm_0,     n,  alu_add,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };

      `RISCV_INST_MSG_BNE     :cs0={ y,  n,    br_bne,  pm_b,   am_rdat, y,  bm_rdat,  y,  alu_xor,  md_x,    n, mdm_x, em_x,   nr,  ml_x, dmm_x,  wm_x,   n,  rx, n   };
      `RISCV_INST_MSG_BEQ     :cs0={ y,  n,    br_beq,  pm_b,   am_rdat, y,  bm_rdat,  y,  alu_xor,  md_x,    n, mdm_x, em_x,   nr,  ml_x, dmm_x,  wm_x,   n,  rx, n   };
      `RISCV_INST_MSG_BLT     :cs0={ y,  n,    br_blt,  pm_b,   am_rdat, y,  bm_rdat,  y,  alu_sub,  md_x,    n, mdm_x, em_x,   nr,  ml_x, dmm_x,  wm_x,   n,  rx, n   };
      `RISCV_INST_MSG_BGE     :cs0={ y,  n,    br_bge,  pm_b,   am_rdat, y,  bm_rdat,  y,  alu_sub,  md_x,    n, mdm_x, em_x,   nr,  ml_x, dmm_x,  wm_x,   n,  rx, n   };
      `RISCV_INST_MSG_BLTU    :cs0={ y,  n,    br_bltu, pm_b,   am_rdat, y,  bm_rdat,  y,  alu_sub,  md_x,    n, mdm_x, em_x,   nr,  ml_x, dmm_x,  wm_x,   n,  rx, n   };
      `RISCV_INST_MSG_BGEU    :cs0={ y,  n,    br_bgeu, pm_b,   am_rdat, y,  bm_rdat,  y,  alu_sub,  md_x,    n, mdm_x, em_x,   nr,  ml_x, dmm_x,  wm_x,   n,  rx, n   };

      `RISCV_INST_MSG_MUL     :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_x,    md_mul,  y, mdm_l, em_md,  nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_DIV     :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_x,    md_div,  y, mdm_l, em_md,  nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_REM     :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_x,    md_rem,  y, mdm_u, em_md,  nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_DIVU    :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_x,    md_divu, y, mdm_l, em_md,  nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };
      `RISCV_INST_MSG_REMU    :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_x,    md_remu, y, mdm_u, em_md,  nr,  ml_x, dmm_x,  wm_alu, y,  rd0, n   };

      `RISCV_INST_MSG_CSRW    :cs0={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_0,     y,  alu_add,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, n,  rx, y   };

    endcase

  end

  always @ (*) begin

    cs1 = {cs_sz{1'bx}}; // Default to invalid instruction

    casez ( ir1_Dhl )

      //                                j     br       pc      op0      rs1 op1       rs2 alu       md       md md     ex      mem  mem   memresp wb      rf      csr
      //                            val taken type     muxsel  muxsel   en  muxsel    en  fn        fn       en muxsel muxsel  rq   len   muxsel  muxsel  wen wa  wen
      `RISCV_INST_MSG_LUI     :cs1={ y,  n,    br_none, pm_p,   am_0,    n,  bm_imm_u, n,  alu_add,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_AUIPC   :cs1={ y,  n,    br_none, pm_p,   am_pc,   n,  bm_imm_u, n,  alu_add,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };

      `RISCV_INST_MSG_ADDI    :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_add,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_ORI     :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_or,   md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_SLTI    :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_lt,   md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_SLTIU   :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_ltu,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_XORI    :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_xor,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_ANDI    :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_and,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_SLLI    :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_sll,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_SRLI    :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_srl,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_SRAI    :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_sra,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };

      `RISCV_INST_MSG_ADD     :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_add,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_SUB     :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_sub,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_SLL     :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_sll,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_SLT     :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_lt,   md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_SLTU    :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_ltu,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_XOR     :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_xor,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_SRL     :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_srl,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_SRA     :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_sra,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_OR      :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_or,   md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_AND     :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_and,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };

      `RISCV_INST_MSG_LW      :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_add,  md_x,    n, mdm_x, em_x,   ld,  ml_w, dmm_w,  wm_mem, y,  rd1, n   };
      `RISCV_INST_MSG_LB      :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_add,  md_x,    n, mdm_x, em_x,   ld,  ml_b, dmm_b,  wm_mem, y,  rd1, n   };
      `RISCV_INST_MSG_LH      :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_add,  md_x,    n, mdm_x, em_x,   ld,  ml_h, dmm_h,  wm_mem, y,  rd1, n   };
      `RISCV_INST_MSG_LBU     :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_add,  md_x,    n, mdm_x, em_x,   ld,  ml_b, dmm_bu, wm_mem, y,  rd1, n   };
      `RISCV_INST_MSG_LHU     :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_i, n,  alu_add,  md_x,    n, mdm_x, em_x,   ld,  ml_h, dmm_hu, wm_mem, y,  rd1, n   };
      `RISCV_INST_MSG_SW      :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_s, y,  alu_add,  md_x,    n, mdm_x, em_x,   st,  ml_w, dmm_w,  wm_mem, n,  rx, n   };
      `RISCV_INST_MSG_SB      :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_s, y,  alu_add,  md_x,    n, mdm_x, em_x,   st,  ml_b, dmm_b,  wm_mem, n,  rx, n   };
      `RISCV_INST_MSG_SH      :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_imm_s, y,  alu_add,  md_x,    n, mdm_x, em_x,   st,  ml_h, dmm_h,  wm_mem, n,  rx, n   };

      `RISCV_INST_MSG_JAL     :cs1={ y,  y,    br_none, pm_j,   am_pc4,  n,  bm_0,     n,  alu_add,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_JALR    :cs1={ y,  y,    br_none, pm_r,   am_pc4,  y,  bm_0,     n,  alu_add,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };

      `RISCV_INST_MSG_BNE     :cs1={ y,  n,    br_bne,  pm_b,   am_rdat, y,  bm_rdat,  y,  alu_xor,  md_x,    n, mdm_x, em_x,   nr,  ml_x, dmm_x,  wm_x,   n,  rx, n   };
      `RISCV_INST_MSG_BEQ     :cs1={ y,  n,    br_beq,  pm_b,   am_rdat, y,  bm_rdat,  y,  alu_xor,  md_x,    n, mdm_x, em_x,   nr,  ml_x, dmm_x,  wm_x,   n,  rx, n   };
      `RISCV_INST_MSG_BLT     :cs1={ y,  n,    br_blt,  pm_b,   am_rdat, y,  bm_rdat,  y,  alu_sub,  md_x,    n, mdm_x, em_x,   nr,  ml_x, dmm_x,  wm_x,   n,  rx, n   };
      `RISCV_INST_MSG_BGE     :cs1={ y,  n,    br_bge,  pm_b,   am_rdat, y,  bm_rdat,  y,  alu_sub,  md_x,    n, mdm_x, em_x,   nr,  ml_x, dmm_x,  wm_x,   n,  rx, n   };
      `RISCV_INST_MSG_BLTU    :cs1={ y,  n,    br_bltu, pm_b,   am_rdat, y,  bm_rdat,  y,  alu_sub,  md_x,    n, mdm_x, em_x,   nr,  ml_x, dmm_x,  wm_x,   n,  rx, n   };
      `RISCV_INST_MSG_BGEU    :cs1={ y,  n,    br_bgeu, pm_b,   am_rdat, y,  bm_rdat,  y,  alu_sub,  md_x,    n, mdm_x, em_x,   nr,  ml_x, dmm_x,  wm_x,   n,  rx, n   };

      `RISCV_INST_MSG_MUL     :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_x,    md_mul,  y, mdm_l, em_md,  nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_DIV     :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_x,    md_div,  y, mdm_l, em_md,  nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_REM     :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_x,    md_rem,  y, mdm_u, em_md,  nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_DIVU    :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_x,    md_divu, y, mdm_l, em_md,  nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };
      `RISCV_INST_MSG_REMU    :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_rdat,  y,  alu_x,    md_remu, y, mdm_u, em_md,  nr,  ml_x, dmm_x,  wm_alu, y,  rd1, n   };

      `RISCV_INST_MSG_CSRW    :cs1={ y,  n,    br_none, pm_p,   am_rdat, y,  bm_0,     y,  alu_add,  md_x,    n, mdm_x, em_alu, nr,  ml_x, dmm_x,  wm_alu, n,  rx, y   };

    endcase

  end

  // Steering Logic

  reg  inst0_issued_Dhl;

  wire stall_0_hazard_Dhl;
  wire stall_1_hazard_Dhl;

  // D to FUA
  reg [ 1:0] pc_mux_sel_Dhl;
  reg [ 2:0] br_sel_Dhl;
  reg        brj_taken_Dhl;
  reg [ 3:0] aluA_fn_Dhl;
  reg        muldivreq_val_Dhl;
  reg        muldiv_mux_sel_Dhl;
  reg        execute_mux_sel_Dhl;
  reg        is_load_Dhl;
  reg        dmemreq_msg_rw_Dhl;
  reg [ 1:0] dmemreq_msg_len_Dhl;
  reg        dmemreq_val_Dhl;
  reg [ 2:0] dmemresp_mux_sel_Dhl;
  reg        memex_mux_sel_Dhl;
  reg        rfA_wen_Dhl;
  reg [ 4:0] rfA_waddr_Dhl;
  reg        csr_wen_Dhl;
  reg [11:0] csr_addr_Dhl;
  reg        is_load_A_Dhl;
  reg        is_muldiv_A_Dhl;

  // D to FUB
  reg [ 3:0] aluB_fn_Dhl;
  reg        rfB_wen_Dhl;
  reg [ 4:0] rfB_waddr_Dhl;

  wire [ 3:0] src00_byp_mux_sel;
  wire [ 3:0] src01_byp_mux_sel;
  wire [ 3:0] src10_byp_mux_sel;
  wire [ 3:0] src11_byp_mux_sel;

/*

First turn for this pair (inst0_issued_Dhl = 0)

 #    Situation                   sel      A gets                                 B gets                  D        Bit next
───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
 1    ALU + ALU                   0        inst0                                  inst1                   advance  0
 2    ALU + non-ALU               1        inst1                                  inst0                   advance  0
 3    lw/mul + ALU                0        inst0                                  inst1                   advance  0
 4    Non-ALU + non-ALU           0        inst0                                  bubble                  hold     1
 5    inst1 has RAW/WAW on inst0  by type  inst0 alone, in the pipe sel gives it                          hold     1
 6    inst0 is a branch           0        inst0                                  bubble                  hold     1
 7    inst0 is jal/jalr           0        inst0                                  bubble (inst1 dropped)  advance  0
 8    inst0 has a hazard          by type  bubble                                 bubble                  hold     0
 9    Only inst1 has a hazard     by type  inst0 alone, in the pipe sel gives it                          hold     1

Second turn (inst0_issued_Dhl = 1), so sel is always 1

 #    Situation           A gets  B gets  D        Bit next
────────────────────────────────────────────────────────────
10    inst1 is ready      inst1   bubble  advance  0
11    inst1 has a hazard  bubble  bubble  hold     1

*/

  // ALU / non-ALU
  wire is_nonalu_0 = (is_load_0_Dhl || dmemreq_msg_rw_0_Dhl || brj_taken_0_Dhl ||
                      (br_sel_0_Dhl != br_none) || is_muldiv_0_Dhl || csr_wen_0_Dhl);
  wire is_nonalu_1 = (is_load_1_Dhl || dmemreq_msg_rw_1_Dhl || brj_taken_1_Dhl ||
                      (br_sel_1_Dhl != br_none) || is_muldiv_1_Dhl || csr_wen_1_Dhl);
  wire is_alu_0    = !is_nonalu_0;
  wire is_alu_1    = !is_nonalu_1;

  // Branch prediction: the branch steered to FUA is predicted taken only
  // if F guessed it (BTB hit, predicted taken) and the BTB target matches
  // branch_targ_Dhl. Otherwise it is predicted not taken.

  wire is_branch_A_Dhl     = (br_sel_Dhl != br_none);
  wire bp_pred_taken_A_Dhl = is_branch_A_Dhl && f_pred_A_Dhl && btb_match_br_Dhl;

  // inst0 jump / branch
  wire is_jump_0_Dhl = cs0[`RISCV_INST_MSG_J_EN];
  wire is_branch_0_Dhl = (br_sel_0_Dhl != br_none);

  // A predicted-taken branch in inst0 behaves like a jump: inst1 is
  // on the wrong path, so it is dropped instead of held (row 6). On inst0's
  // turn sel is 0, so the instruction in A is inst0. A predicted-not-taken
  // branch keeps the row 6 hold.
  wire drop_1_Dhl = is_jump_0_Dhl
                 || ( !inst0_issued_Dhl && is_branch_0_Dhl && bp_pred_taken_A_Dhl );

  // D checks F's guess.
  wire f_pred_A_Dhl = steering_mux_sel_Dhl ? f_pred1_Dhl : f_pred0_Dhl;
  wire is_jal_A_Dhl = brj_taken_Dhl && ( pc_mux_sel_Dhl == pm_j );
  wire f_done_j_Dhl = f_pred_A_Dhl && is_jal_A_Dhl && btb_match_j_Dhl;

  // A jump redirects from D, unless F already went to the same target.
  // A predicted-taken branch never redirects from D: F already did.
  wire d_jump_redir_Dhl = issue_A_Dhl && brj_taken_Dhl && !f_done_j_Dhl;

  // F guessed a slot taken, but D says that slot does not redirect
  wire d_taken_A_Dhl   = brj_taken_Dhl || bp_pred_taken_A_Dhl;
  wire taken_slot0_Dhl = !steering_mux_sel_Dhl && d_taken_A_Dhl;
  wire taken_slot1_Dhl =  steering_mux_sel_Dhl && d_taken_A_Dhl;
  wire issue_1_Dhl     = inst_val_Dhl && !stall_1_Dhl;
  wire f_corr_Dhl      = ( f_pred0_Dhl && issue_0_Dhl && !taken_slot0_Dhl )
                      || ( f_pred1_Dhl && issue_1_Dhl && !taken_slot1_Dhl );

  // Hazard between inst0 and inst1
  wire raw_1_on_0_Dhl = rf0_wen_Dhl && (rf0_waddr_Dhl != 5'd0) && (
                        (rs11_en_Dhl && (rs11_addr_Dhl == rf0_waddr_Dhl)) ||
                        (rs21_en_Dhl && (rs21_addr_Dhl == rf0_waddr_Dhl)));
  wire waw_1_on_0_Dhl = rf0_wen_Dhl && rf1_wen_Dhl && (rf0_waddr_Dhl != 5'd0) && 
                        (rf0_waddr_Dhl == rf1_waddr_Dhl);

  // inst1 blocked by inst0, # 4-7
  wire split_Dhl = (is_nonalu_0 && is_nonalu_1) || (raw_1_on_0_Dhl || waw_1_on_0_Dhl) ||
                    is_jump_0_Dhl || is_branch_0_Dhl;

  // inst can not issue this cycle
  // # 8
  wire stall_0_Dhl = !inst0_issued_Dhl && (stall_X0hl || (inst_val_Dhl && stall_0_hazard_Dhl));
  // # 9
  wire stall_1_Dhl = stall_X0hl || (inst_val_Dhl && (stall_1_hazard_Dhl
                       || (!inst0_issued_Dhl && (stall_0_Dhl || split_Dhl))));

  // FU
  wire stall_A_Dhl = steering_mux_sel_Dhl ? stall_1_Dhl : stall_0_Dhl;
  wire stall_B_Dhl = inst0_issued_Dhl     ? 1'b1                       // B holds inst0 again
                   : steering_mux_sel_Dhl ? stall_0_Dhl : stall_1_Dhl;

  wire issue_A_Dhl = inst_val_Dhl && !stall_A_Dhl;                      // jump redirect
  wire issue_0_Dhl = inst_val_Dhl && !inst0_issued_Dhl && !stall_0_Dhl; // inst0 leaves D

  always @( posedge clk ) begin
    if (reset || squash_Dhl)
      inst0_issued_Dhl <= 1'b0;
    else if ( !stall_Dhl )
      inst0_issued_Dhl <= 1'b0;
    else if ( issue_0_Dhl )
      inst0_issued_Dhl <= 1'b1;
  end

  always @(*) begin
    steering_mux_sel_Dhl = (is_alu_0 && is_nonalu_1) || // # 1-3
                           inst0_issued_Dhl;            // # 10-11
  end

  //----------------------------------------------------------------------
  // Profiling counters
  //----------------------------------------------------------------------

  `ifndef SYNTHESIS

  reg [31:0] profile_dempty;        // D empty: bubble or squashed pair
  reg [31:0] profile_memstall;      // X0/X1 stalled, nothing issues
  reg [31:0] profile_turn2_hazard;  // 2nd turn, inst1 waits on a hazard
  reg [31:0] profile_turn2_issue;   // 2nd turn, inst1 issues alone
  reg [31:0] profile_inst0hazard;   // inst0 hazard, nothing issues
  reg [31:0] profile_jump;          // inst0 jump issues, inst1 dropped
  reg [31:0] profile_br_hold;       // inst0 branch issues alone
  reg [31:0] profile_both_nonalu;   // inst0 issues alone, both need FUA
  reg [31:0] profile_rawhazard;     // inst0 issues alone, inst1 RAW
  reg [31:0] profile_wawhazard;     // inst0 issues alone, inst1 WAW
  reg [31:0] profile_inst1hazard;   // inst0 issues alone, inst1 hazard
  reg [31:0] profile_dual_issue;    // both instructions issue
  reg [31:0] profile_total;         // all cycles, for the sum check
  reg [31:0] profile_branches;      // branches resolved in X0 (not a cycle category)
  reg [31:0] profile_br_taken;      // of those, actually taken
  reg [31:0] profile_br_nottaken;   // of those, actually not taken
  reg [31:0] profile_mispredicts;   // of those, mispredicted

  always @(posedge clk) begin
    if (reset) begin
      profile_branches     <= 32'd0;
      profile_br_taken     <= 32'd0;
      profile_br_nottaken  <= 32'd0;
      profile_mispredicts  <= 32'd0;
    end
    else if (is_branch_X0hl && !stall_X0hl) begin
      profile_branches    <= profile_branches + 1;
      if (any_br_taken_X0hl)
        profile_br_taken    <= profile_br_taken + 1;
      else
        profile_br_nottaken <= profile_br_nottaken + 1;
      if (bp_miss_X0hl)
        profile_mispredicts <= profile_mispredicts + 1;
    end
  end

  always @(posedge clk) begin
    if (reset) begin
      profile_dempty       <= 32'd0;
      profile_memstall     <= 32'd0;
      profile_turn2_hazard <= 32'd0;
      profile_turn2_issue  <= 32'd0;
      profile_inst0hazard  <= 32'd0;
      profile_jump         <= 32'd0;
      profile_br_hold      <= 32'd0;
      profile_both_nonalu  <= 32'd0;
      profile_rawhazard    <= 32'd0;
      profile_wawhazard    <= 32'd0;
      profile_inst1hazard  <= 32'd0;
      profile_dual_issue   <= 32'd0;
      profile_total        <= 32'd0;
    end
    else begin
      profile_total <= profile_total + 1;

      if (!inst_val_Dhl)
        profile_dempty <= profile_dempty + 1;
      else if (stall_X0hl)
        profile_memstall <= profile_memstall + 1;
      else if (inst0_issued_Dhl) begin
        if (stall_1_hazard_Dhl)
          profile_turn2_hazard <= profile_turn2_hazard + 1;
        else
          profile_turn2_issue <= profile_turn2_issue + 1;
      end
      else if (stall_0_hazard_Dhl)
        profile_inst0hazard <= profile_inst0hazard + 1;
      else if (is_jump_0_Dhl)
        profile_jump <= profile_jump + 1;
      else if (is_branch_0_Dhl)
        profile_br_hold <= profile_br_hold + 1;
      else if (is_nonalu_0 && is_nonalu_1)
        profile_both_nonalu <= profile_both_nonalu + 1;
      else if (raw_1_on_0_Dhl)
        profile_rawhazard <= profile_rawhazard + 1;
      else if (waw_1_on_0_Dhl)
        profile_wawhazard <= profile_wawhazard + 1;
      else if (stall_1_hazard_Dhl)
        profile_inst1hazard <= profile_inst1hazard + 1;
      else
        profile_dual_issue <= profile_dual_issue + 1;
    end
  end

  // Print once, when the program writes a nonzero status (end of run)

  reg profile_printed;

  always @(posedge clk) begin
    if (reset)
      profile_printed <= 1'b0;
    else if (!profile_printed && (csr_status != 32'd0)) begin
      profile_printed <= 1'b1;
      $display( "--------------------------------------------" );
      $display( " PROFILE (cycles in D)                      " );
      $display( "--------------------------------------------" );
      $display( " dual_issue      = %d", profile_dual_issue   );
      $display( " turn2_issue     = %d", profile_turn2_issue  );
      $display( " turn2_hazard    = %d", profile_turn2_hazard );
      $display( " jump            = %d", profile_jump         );
      $display( " br_hold         = %d", profile_br_hold      );
      $display( " both_nonalu     = %d", profile_both_nonalu  );
      $display( " raw             = %d", profile_rawhazard    );
      $display( " waw             = %d", profile_wawhazard    );
      $display( " inst1_hazard    = %d", profile_inst1hazard  );
      $display( " inst0_hazard    = %d", profile_inst0hazard  );
      $display( " mem_stall       = %d", profile_memstall     );
      $display( " d_empty         = %d", profile_dempty       );
      $display( " total           = %d", profile_total        );
      $display( " branches        = %d", profile_branches     );
      $display( " br_taken        = %d", profile_br_taken     );
      $display( " br_nottaken     = %d", profile_br_nottaken  );
      $display( " mispredicts     = %d", profile_mispredicts  );
      $display( " sum_categories  = %d",
                profile_dual_issue + profile_turn2_issue + profile_turn2_hazard
              + profile_jump + profile_br_hold + profile_both_nonalu
              + profile_rawhazard + profile_wawhazard + profile_inst1hazard + profile_inst0hazard
              + profile_memstall + profile_dempty );
    end
  end

  reg [31:0] f_used;
  reg [31:0] f_corr_cnt;
  reg [31:0] d_redir_cnt;

  always @(posedge clk) begin
    if (reset) begin
      f_used <= 0;
      f_corr_cnt <= 0;
      d_redir_cnt <= 0;
    end
    else begin
      if (imem_pair_consumed_Fhl && (f_pred0_Fhl||f_pred1_Fhl) && pc_mux_sel_Phl==pmx_btb)
        f_used <= f_used + 1;
      if (f_corr_Dhl && pc_mux_sel_Phl==pmx_seq)
        f_corr_cnt <= f_corr_cnt + 1;
      if (d_jump_redir_Dhl && !bp_miss_X0hl)
        d_redir_cnt <= d_redir_cnt + 1;
    end
  end

  always @(posedge clk) begin
    if (!reset && profile_printed===1'b0 && csr_status != 0) begin
      $display(" fp f_guesses_used=%0d d_corrections=%0d d_redirects=%0d", f_used, f_corr_cnt, d_redir_cnt);
    end
  end

  `endif

  always @(*) begin
    // FUA
    instA_Dhl            = 0;
    pc_mux_sel_Dhl       = 0;
    br_sel_Dhl           = 0;
    brj_taken_Dhl        = 0;
    aluA_fn_Dhl          = 0;
    muldivreq_val_Dhl    = 0;
    muldiv_mux_sel_Dhl   = 0;
    execute_mux_sel_Dhl  = 0;
    is_load_Dhl          = 0;
    dmemreq_msg_rw_Dhl   = 0;
    dmemreq_msg_len_Dhl  = 0;
    dmemreq_val_Dhl      = 0;
    dmemresp_mux_sel_Dhl = 0;
    memex_mux_sel_Dhl    = 0;
    rfA_wen_Dhl          = 0;
    rfA_waddr_Dhl        = 0;
    csr_wen_Dhl          = 0;
    csr_addr_Dhl         = 0;
    opA0_mux_sel_Dhl     = 0;
    opA1_mux_sel_Dhl     = 0;
    muldivreq_msg_fn_Dhl = 0;
    opA0_byp_mux_sel_Dhl = 0;
    opA1_byp_mux_sel_Dhl = 0;
    is_load_A_Dhl        = 0;
    is_muldiv_A_Dhl      = 0;

    // FUB
    instB_Dhl            = 0;
    aluB_fn_Dhl          = 0;
    rfB_wen_Dhl          = 0;
    rfB_waddr_Dhl        = 0;
    opB0_mux_sel_Dhl     = 0;
    opB1_mux_sel_Dhl     = 0;
    opB0_byp_mux_sel_Dhl = 0;
    opB1_byp_mux_sel_Dhl = 0;

    if ( steering_mux_sel_Dhl == 1'b0 ) begin
      // D to FUA
      instA_Dhl            = ir0_Dhl;
      pc_mux_sel_Dhl       = pc_mux_sel_0_Dhl;
      br_sel_Dhl           = br_sel_0_Dhl;
      brj_taken_Dhl        = brj_taken_0_Dhl;
      aluA_fn_Dhl          = alu0_fn_Dhl;
      muldivreq_val_Dhl    = muldivreq_val_0_Dhl;
      muldiv_mux_sel_Dhl   = muldiv_mux_sel_0_Dhl;
      execute_mux_sel_Dhl  = execute_mux_sel_0_Dhl;
      is_load_Dhl          = is_load_0_Dhl;
      dmemreq_msg_rw_Dhl   = dmemreq_msg_rw_0_Dhl;
      dmemreq_msg_len_Dhl  = dmemreq_msg_len_0_Dhl;
      dmemreq_val_Dhl      = dmemreq_val_0_Dhl;
      dmemresp_mux_sel_Dhl = dmemresp_mux_sel_0_Dhl;
      memex_mux_sel_Dhl    = memex_mux_sel_0_Dhl;
      rfA_wen_Dhl          = rf0_wen_Dhl;
      rfA_waddr_Dhl        = rf0_waddr_Dhl;
      csr_wen_Dhl          = csr_wen_0_Dhl;
      csr_addr_Dhl         = csr_addr_0_Dhl;
      opA0_mux_sel_Dhl     = op00_mux_sel_Dhl;
      opA1_mux_sel_Dhl     = op01_mux_sel_Dhl;
      muldivreq_msg_fn_Dhl = muldivreq_msg_fn_0_Dhl;
      opA0_byp_mux_sel_Dhl = src00_byp_mux_sel;
      opA1_byp_mux_sel_Dhl = src01_byp_mux_sel;
      is_load_A_Dhl        = is_load_0_Dhl;
      is_muldiv_A_Dhl      = is_muldiv_0_Dhl;

      // D to B
      instB_Dhl            = ir1_Dhl;
      aluB_fn_Dhl          = alu1_fn_Dhl;
      rfB_wen_Dhl          = rf1_wen_Dhl;
      rfB_waddr_Dhl        = rf1_waddr_Dhl;
      opB0_mux_sel_Dhl     = op10_mux_sel_Dhl;
      opB1_mux_sel_Dhl     = op11_mux_sel_Dhl;
      opB0_byp_mux_sel_Dhl = src10_byp_mux_sel;
      opB1_byp_mux_sel_Dhl = src11_byp_mux_sel;
    end
    else if ( steering_mux_sel_Dhl == 1'b1 ) begin
      // D to FUA
      instA_Dhl            = ir1_Dhl;
      pc_mux_sel_Dhl       = pc_mux_sel_1_Dhl;
      br_sel_Dhl           = br_sel_1_Dhl;
      brj_taken_Dhl        = brj_taken_1_Dhl;
      aluA_fn_Dhl          = alu1_fn_Dhl;
      muldivreq_val_Dhl    = muldivreq_val_1_Dhl;
      muldiv_mux_sel_Dhl   = muldiv_mux_sel_1_Dhl;
      execute_mux_sel_Dhl  = execute_mux_sel_1_Dhl;
      is_load_Dhl          = is_load_1_Dhl;
      dmemreq_msg_rw_Dhl   = dmemreq_msg_rw_1_Dhl;
      dmemreq_msg_len_Dhl  = dmemreq_msg_len_1_Dhl;
      dmemreq_val_Dhl      = dmemreq_val_1_Dhl;
      dmemresp_mux_sel_Dhl = dmemresp_mux_sel_1_Dhl;
      memex_mux_sel_Dhl    = memex_mux_sel_1_Dhl;
      rfA_wen_Dhl          = rf1_wen_Dhl;
      rfA_waddr_Dhl        = rf1_waddr_Dhl;
      csr_wen_Dhl          = csr_wen_1_Dhl;
      csr_addr_Dhl         = csr_addr_1_Dhl;
      opA0_mux_sel_Dhl     = op10_mux_sel_Dhl;
      opA1_mux_sel_Dhl     = op11_mux_sel_Dhl;
      muldivreq_msg_fn_Dhl = muldivreq_msg_fn_1_Dhl;
      opA0_byp_mux_sel_Dhl = src10_byp_mux_sel;
      opA1_byp_mux_sel_Dhl = src11_byp_mux_sel;
      is_load_A_Dhl        = is_load_1_Dhl;
      is_muldiv_A_Dhl      = is_muldiv_1_Dhl;

      // D to B
      instB_Dhl            = ir0_Dhl;
      aluB_fn_Dhl          = alu0_fn_Dhl;
      rfB_wen_Dhl          = rf0_wen_Dhl;
      rfB_waddr_Dhl        = rf0_waddr_Dhl;
      opB0_mux_sel_Dhl     = op00_mux_sel_Dhl;
      opB1_mux_sel_Dhl     = op01_mux_sel_Dhl;
      opB0_byp_mux_sel_Dhl = src00_byp_mux_sel;
      opB1_byp_mux_sel_Dhl = src01_byp_mux_sel;
    end
  end


  wire [4:0] rs10_addr_Dhl  = inst0_rs1_Dhl;
  wire [4:0] rs20_addr_Dhl  = inst0_rs2_Dhl;

  wire [4:0] rs11_addr_Dhl  = inst1_rs1_Dhl;
  wire [4:0] rs21_addr_Dhl  = inst1_rs2_Dhl;

  wire       rs10_en_Dhl    = cs0[`RISCV_INST_MSG_RS1_EN];
  wire       rs20_en_Dhl    = cs0[`RISCV_INST_MSG_RS2_EN];

  wire       rs11_en_Dhl    = cs1[`RISCV_INST_MSG_RS1_EN];
  wire       rs21_en_Dhl    = cs1[`RISCV_INST_MSG_RS2_EN];

  // Jump and Branch Controls

  wire       brj_taken_0_Dhl = ( inst_val_Dhl && cs0[`RISCV_INST_MSG_J_EN] );
  wire       brj_taken_1_Dhl = ( inst_val_Dhl && cs1[`RISCV_INST_MSG_J_EN] );

  wire [2:0] br_sel_0_Dhl = cs0[`RISCV_INST_MSG_BR_SEL];
  wire [2:0] br_sel_1_Dhl = cs1[`RISCV_INST_MSG_BR_SEL];

  // PC Mux Select

  wire [1:0] pc_mux_sel_0_Dhl = cs0[`RISCV_INST_MSG_PC_SEL];
  wire [1:0] pc_mux_sel_1_Dhl = cs1[`RISCV_INST_MSG_PC_SEL];

  // Operand Mux Select

  wire [1:0] op00_mux_sel_Dhl = cs0[`RISCV_INST_MSG_OP0_SEL];
  wire [2:0] op01_mux_sel_Dhl = cs0[`RISCV_INST_MSG_OP1_SEL];

  wire [1:0] op10_mux_sel_Dhl = cs1[`RISCV_INST_MSG_OP0_SEL];
  wire [2:0] op11_mux_sel_Dhl = cs1[`RISCV_INST_MSG_OP1_SEL];

  // ALU Function

  wire [3:0] alu0_fn_Dhl = cs0[`RISCV_INST_MSG_ALU_FN];
  wire [3:0] alu1_fn_Dhl = cs1[`RISCV_INST_MSG_ALU_FN];

  // Muldiv Function

  wire [2:0] muldivreq_msg_fn_0_Dhl = cs0[`RISCV_INST_MSG_MULDIV_FN];
  wire [2:0] muldivreq_msg_fn_1_Dhl = cs1[`RISCV_INST_MSG_MULDIV_FN];

  // Muldiv Controls

  wire       muldivreq_val_0_Dhl = cs0[`RISCV_INST_MSG_MULDIV_EN];
  wire       muldivreq_val_1_Dhl = cs1[`RISCV_INST_MSG_MULDIV_EN];

  // Muldiv Mux Select

  wire       muldiv_mux_sel_0_Dhl = cs0[`RISCV_INST_MSG_MULDIV_SEL];
  wire       muldiv_mux_sel_1_Dhl = cs1[`RISCV_INST_MSG_MULDIV_SEL];

  wire       is_muldiv_0_Dhl = cs0[`RISCV_INST_MSG_MULDIV_EN];
  wire       is_muldiv_1_Dhl = cs1[`RISCV_INST_MSG_MULDIV_EN];

  // Execute Mux Select

  wire       execute_mux_sel_0_Dhl = cs0[`RISCV_INST_MSG_MULDIV_EN];
  wire       execute_mux_sel_1_Dhl = cs1[`RISCV_INST_MSG_MULDIV_EN];

  wire       is_load_0_Dhl = ( cs0[`RISCV_INST_MSG_MEM_REQ] == ld );
  wire       is_load_1_Dhl = ( cs1[`RISCV_INST_MSG_MEM_REQ] == ld );

  wire       dmemreq_msg_rw_0_Dhl = ( cs0[`RISCV_INST_MSG_MEM_REQ] == st );
  wire       dmemreq_msg_rw_1_Dhl = ( cs1[`RISCV_INST_MSG_MEM_REQ] == st );

  wire [1:0] dmemreq_msg_len_0_Dhl = cs0[`RISCV_INST_MSG_MEM_LEN];
  wire [1:0] dmemreq_msg_len_1_Dhl = cs1[`RISCV_INST_MSG_MEM_LEN];

  wire       dmemreq_val_0_Dhl = ( cs0[`RISCV_INST_MSG_MEM_REQ] != nr );
  wire       dmemreq_val_1_Dhl = ( cs1[`RISCV_INST_MSG_MEM_REQ] != nr );

  // Memory response mux select

  wire [2:0] dmemresp_mux_sel_0_Dhl = cs0[`RISCV_INST_MSG_MEM_SEL];
  wire [2:0] dmemresp_mux_sel_1_Dhl = cs1[`RISCV_INST_MSG_MEM_SEL];

  // Writeback Mux Select

  wire       memex_mux_sel_0_Dhl = cs0[`RISCV_INST_MSG_WB_SEL];
  wire       memex_mux_sel_1_Dhl = cs1[`RISCV_INST_MSG_WB_SEL];

  // Register Writeback Controls

  wire       rf0_wen_Dhl   = cs0[`RISCV_INST_MSG_RF_WEN];
  wire [4:0] rf0_waddr_Dhl = cs0[`RISCV_INST_MSG_RF_WADDR];

  wire       rf1_wen_Dhl   = cs1[`RISCV_INST_MSG_RF_WEN];
  wire [4:0] rf1_waddr_Dhl = cs1[`RISCV_INST_MSG_RF_WADDR];

  // CSR register write enable

  wire       csr_wen_0_Dhl = cs0[`RISCV_INST_MSG_CSR_WEN];
  wire       csr_wen_1_Dhl = cs1[`RISCV_INST_MSG_CSR_WEN];

  // CSR register address

  wire [11:0] csr_addr_0_Dhl = ir0_Dhl[31:20];
  wire [11:0] csr_addr_1_Dhl = ir1_Dhl[31:20];

  //----------------------------------------------------------------------
  // Scoreboard
  //----------------------------------------------------------------------

  // Late bypass of a mul result (see the scoreboard). An instruction that
  // uses its operands already in D cannot take a value late: mul/div send
  // their operands to the multiplier from D, and jalr computes its target
  // in D. For those the scoreboard keeps the stall.
  wire nolate_0_Dhl = is_muldiv_0_Dhl || ( cs0[`RISCV_INST_MSG_J_EN] && ( pc_mux_sel_0_Dhl == pm_r ) );
  wire nolate_1_Dhl = is_muldiv_1_Dhl || ( cs1[`RISCV_INST_MSG_J_EN] && ( pc_mux_sel_1_Dhl == pm_r ) );
  wire src00_late_Dhl, src01_late_Dhl, src10_late_Dhl, src11_late_Dhl;

  // Per pipeline, only where the operand really comes from a register
  wire lA0_Dhl = steering_mux_sel_Dhl ? src10_late_Dhl : src00_late_Dhl;  // rs1 of the inst in FUA
  wire lA1_Dhl = steering_mux_sel_Dhl ? src11_late_Dhl : src01_late_Dhl;  // rs2 of the inst in FUA
  wire lB0_Dhl = steering_mux_sel_Dhl ? src00_late_Dhl : src10_late_Dhl;
  wire lB1_Dhl = steering_mux_sel_Dhl ? src01_late_Dhl : src11_late_Dhl;
  wire lateA0_Dhl = lA0_Dhl && ( opA0_mux_sel_Dhl == am_rdat );
  wire lateA1_Dhl = lA1_Dhl && ( opA1_mux_sel_Dhl == bm_rdat );
  wire lateWd_Dhl = lA1_Dhl && dmemreq_msg_rw_Dhl;                       // store data is rs2
  wire lateB0_Dhl = lB0_Dhl && ( opB0_mux_sel_Dhl == am_rdat );
  wire lateB1_Dhl = lB1_Dhl && ( opB1_mux_sel_Dhl == bm_rdat );

  // The flags go into X0 with the instruction. If X0 stalls, the datapath
  // writes the forwarded value into the X0 operand register in that cycle
  // (the mul is still in X3), so the flag is cleared and the value kept.
  always @( posedge clk ) begin
    if ( reset ) begin
      lateA0_X0hl <= 1'b0; lateA1_X0hl <= 1'b0; lateWd_X0hl <= 1'b0;
      lateB0_X0hl <= 1'b0; lateB1_X0hl <= 1'b0;
    end
    else if ( !stall_X0hl ) begin
      lateA0_X0hl <= lateA0_Dhl; lateA1_X0hl <= lateA1_Dhl; lateWd_X0hl <= lateWd_Dhl;
      lateB0_X0hl <= lateB0_Dhl; lateB1_X0hl <= lateB1_Dhl;
    end
    else begin
      lateA0_X0hl <= 1'b0; lateA1_X0hl <= 1'b0; lateWd_X0hl <= 1'b0;
      lateB0_X0hl <= 1'b0; lateB1_X0hl <= 1'b0;
    end
  end

  riscv_CoreScoreboard scoreboard
  (
    .clk               (clk),
    .reset             (reset),

    .inst_val_Dhl      (inst_val_Dhl),

    .src00             (rs10_addr_Dhl),
    .src00_en          (rs10_en_Dhl),
    .src01             (rs20_addr_Dhl),
    .src01_en          (rs20_en_Dhl),
    .src10             (rs11_addr_Dhl),
    .src10_en          (rs11_en_Dhl),
    .src11             (rs21_addr_Dhl),
    .src11_en          (rs21_en_Dhl),

    .stall_0_hazard    (stall_0_hazard_Dhl),
    .stall_1_hazard    (stall_1_hazard_Dhl),

    .nolate_0          (nolate_0_Dhl),
    .nolate_1          (nolate_1_Dhl),
    .src00_late        (src00_late_Dhl),
    .src01_late        (src01_late_Dhl),
    .src10_late        (src10_late_Dhl),
    .src11_late        (src11_late_Dhl),

    .src00_byp_mux_sel (src00_byp_mux_sel),
    .src01_byp_mux_sel (src01_byp_mux_sel),
    .src10_byp_mux_sel (src10_byp_mux_sel),
    .src11_byp_mux_sel (src11_byp_mux_sel),

    .dstA              (rfA_waddr_Dhl),
    .dstA_en           (rfA_wen_Dhl),
    .stall_A_Dhl       (stall_A_Dhl),
    .is_muldiv_A       (is_muldiv_A_Dhl),
    .is_load_A         (is_load_A_Dhl),

    .dstB              (rfB_waddr_Dhl),
    .dstB_en           (rfB_wen_Dhl),
    .stall_B_Dhl       (stall_B_Dhl),

    .stall_X0hl        (stall_X0hl),
    .stall_X1hl        (stall_X1hl)
  );

  //----------------------------------------------------------------------
  // Squash and Stall Logic
  //----------------------------------------------------------------------

  // Squash D only on a misprediction in X0. After a correctly
  // predicted taken branch, D already holds the target's instructions.

  wire squash_Dhl = bp_miss_X0hl;

  // Aggregate Stall Signal

  // D holds the pair until all of it has left (a jump or a predicted-taken
  // branch in inst0 drops inst1)
  assign stall_Dhl = stall_X0hl || (inst_val_Dhl &&
                                    (inst0_issued_Dhl ? stall_1_Dhl
                                                      : (stall_0_Dhl || (!drop_1_Dhl && stall_1_Dhl)))
                                   );

  // Next bubble bit

  wire bubble_sel_Dhl  = ( squash_Dhl || stall_A_Dhl );
  wire bubble_next_Dhl = ( !bubble_sel_Dhl ) ? bubble_Dhl
                       : ( bubble_sel_Dhl )  ? 1'b1
                       :                       1'bx;

  wire bubbleB_sel_Dhl  = ( squash_Dhl || stall_B_Dhl );
  wire bubbleB_next_Dhl = ( !bubbleB_sel_Dhl ) ? bubble_Dhl
                        : ( bubbleB_sel_Dhl )  ? 1'b1
                        :                        1'bx;

  //----------------------------------------------------------------------
  // X0 <- D
  //----------------------------------------------------------------------

  // The D-stage prediction travels into X0 with the branch. The
  // table index comes from pcA_X0hl in the datapath, so no register here.

  // FUA
  reg [31:0] irA_X0hl;
  reg  [2:0] br_sel_X0hl;
  reg        bp_pred_taken_X0hl;
  reg        muldivreq_val_X0hl;
  reg        muldiv_mux_sel_X0hl;
  reg        execute_mux_sel_X0hl;
  reg        is_load_X0hl;
  reg        is_muldiv_X0hl;
  reg        dmemreq_msg_rw_X0hl;
  reg  [1:0] dmemreq_msg_len_X0hl;
  reg        dmemreq_val_X0hl;
  reg  [2:0] dmemresp_mux_sel_X0hl;
  reg        memex_mux_sel_X0hl;
  reg        rfA_wen_X0hl;
  reg  [4:0] rfA_waddr_X0hl;
  reg        csr_wen_X0hl;
  reg [11:0] csr_addr_X0hl;
  reg        bubble_X0hl;

  // FUB
  reg [31:0] irB_X0hl;
  reg        rfB_wen_X0hl;
  reg  [4:0] rfB_waddr_X0hl;
  reg        bubbleB_X0hl;

  // Pipeline Controls

  always @ ( posedge clk ) begin
    if ( reset ) begin
      bubble_X0hl <= 1'b1;
      bubbleB_X0hl <= 1'b1;
    end
    else if( !stall_X0hl ) begin
      irA_X0hl              <= instA_Dhl;
      br_sel_X0hl           <= br_sel_Dhl;
      bp_pred_taken_X0hl    <= bp_pred_taken_A_Dhl;
      aluA_fn_X0hl          <= aluA_fn_Dhl;
      muldivreq_val_X0hl    <= muldivreq_val_Dhl;
      muldiv_mux_sel_X0hl   <= muldiv_mux_sel_Dhl;
      execute_mux_sel_X0hl  <= execute_mux_sel_Dhl;
      is_load_X0hl          <= is_load_Dhl;
      is_muldiv_X0hl        <= muldivreq_val_Dhl;
      dmemreq_msg_rw_X0hl   <= dmemreq_msg_rw_Dhl;
      dmemreq_msg_len_X0hl  <= dmemreq_msg_len_Dhl;
      dmemreq_val_X0hl      <= dmemreq_val_Dhl;
      dmemresp_mux_sel_X0hl <= dmemresp_mux_sel_Dhl;
      memex_mux_sel_X0hl    <= memex_mux_sel_Dhl;
      rfA_wen_X0hl          <= rfA_wen_Dhl;
      rfA_waddr_X0hl        <= rfA_waddr_Dhl;
      csr_wen_X0hl          <= csr_wen_Dhl;
      csr_addr_X0hl         <= csr_addr_Dhl;
      bubble_X0hl           <= bubble_next_Dhl;

      irB_X0hl              <= instB_Dhl;
      aluB_fn_X0hl          <= aluB_fn_Dhl;
      rfB_wen_X0hl          <= rfB_wen_Dhl;
      rfB_waddr_X0hl        <= rfB_waddr_Dhl;
      bubbleB_X0hl          <= bubbleB_next_Dhl;
    end

  end

  //----------------------------------------------------------------------
  // Execute Stage
  //----------------------------------------------------------------------

  // Is the current stage valid?

  wire inst_val_X0hl = ( !bubble_X0hl && !squash_X0hl );

  // Muldiv request

  assign muldivreq_val = muldivreq_val_Dhl && inst_val_Dhl && (!bubble_next_Dhl);
  assign muldivresp_rdy = 1'b1;

  // Only send a valid dmem request if not stalled

  assign dmemreq_msg_rw  = dmemreq_msg_rw_X0hl;
  assign dmemreq_msg_len = dmemreq_msg_len_X0hl;
  assign dmemreq_val     = ( inst_val_X0hl && !stall_X0hl && dmemreq_val_X0hl );

  // Resolve Branch

  wire bne_taken_X0hl  = ( ( br_sel_X0hl == br_bne ) && branch_cond_ne_X0hl );
  wire beq_taken_X0hl  = ( ( br_sel_X0hl == br_beq ) && branch_cond_eq_X0hl );
  wire blt_taken_X0hl  = ( ( br_sel_X0hl == br_blt ) && branch_cond_lt_X0hl );
  wire bltu_taken_X0hl = ( ( br_sel_X0hl == br_bltu) && branch_cond_ltu_X0hl);
  wire bge_taken_X0hl  = ( ( br_sel_X0hl == br_bge ) && branch_cond_ge_X0hl );
  wire bgeu_taken_X0hl = ( ( br_sel_X0hl == br_bgeu) && branch_cond_geu_X0hl);


  wire any_br_taken_X0hl
    = ( beq_taken_X0hl
   ||   bne_taken_X0hl
   ||   blt_taken_X0hl
   ||   bltu_taken_X0hl
   ||   bge_taken_X0hl
   ||   bgeu_taken_X0hl );

  wire brj_taken_X0hl = ( inst_val_X0hl && any_br_taken_X0hl );

  // Misprediction check
  wire is_branch_X0hl        = inst_val_X0hl && (br_sel_X0hl != br_none);
  wire bp_miss_taken_X0hl    = is_branch_X0hl &&  any_br_taken_X0hl && !bp_pred_taken_X0hl;
  wire bp_miss_nottaken_X0hl = is_branch_X0hl && !any_br_taken_X0hl &&  bp_pred_taken_X0hl;
  wire bp_miss_X0hl          = bp_miss_taken_X0hl || bp_miss_nottaken_X0hl;

  // BTB update / fill
  assign btb_br_upd_X0hl   = is_branch_X0hl && !stall_X0hl;
  assign btb_br_taken_X0hl = any_br_taken_X0hl;
  assign btb_jal_fill_Dhl  = issue_A_Dhl && is_jal_A_Dhl;

  // Dummy Squash Signal

  wire squash_X0hl = 1'b0;

  // Stall in X if muldiv reponse is not valid and there was a valid request

  wire stall_muldiv_X0hl = 1'b0; //( muldivreq_val_X0hl && inst_val_X0hl && !muldivresp_val );

  // Stall in X if dmem is not ready and there was a valid request

  wire stall_dmem_X0hl = ( dmemreq_val_X0hl && inst_val_X0hl && !dmemreq_rdy );

  // Aggregate Stall Signal

  assign stall_X0hl = ( stall_X1hl || stall_muldiv_X0hl || stall_dmem_X0hl );

  // Next bubble bit

  wire bubble_sel_X0hl   = ( squash_X0hl || stall_X0hl );
  wire bubble_next_X0hl  = ( !bubble_sel_X0hl ) ? bubble_X0hl
                         : ( bubble_sel_X0hl )  ? 1'b1
                         :                       1'bx;
  wire bubbleB_next_X0hl = ( !bubble_sel_X0hl ) ? bubbleB_X0hl
                         : ( bubble_sel_X0hl )  ? 1'b1
                         :                        1'bx;

  //----------------------------------------------------------------------
  // X1 <- X0
  //----------------------------------------------------------------------

  // FUA
  reg [31:0] irA_X1hl;
  reg        is_load_X1hl;
  reg        is_muldiv_X1hl;
  reg        dmemreq_val_X1hl;
  reg        execute_mux_sel_X1hl;
  reg        muldiv_mux_sel_X1hl;
  reg        rfA_wen_X1hl;
  reg  [4:0] rfA_waddr_X1hl;
  reg        csr_wen_X1hl;
  reg  [4:0] csr_addr_X1hl;
  reg        bubble_X1hl;

  // FUB
  reg [31:0] irB_X1hl;
  reg        rfB_wen_X1hl;
  reg  [4:0] rfB_waddr_X1hl;
  reg        bubbleB_X1hl;

  // Pipeline Controls

  always @ ( posedge clk ) begin
    if ( reset ) begin
      dmemreq_val_X1hl <= 1'b0;
      bubble_X1hl <= 1'b1;
      bubbleB_X1hl <= 1'b1;
    end
    else if( !stall_X1hl ) begin
      irA_X1hl              <= irA_X0hl;
      is_load_X1hl          <= is_load_X0hl;
      is_muldiv_X1hl        <= is_muldiv_X0hl;
      dmemreq_val_X1hl      <= dmemreq_val;
      dmemresp_mux_sel_X1hl <= dmemresp_mux_sel_X0hl;
      memex_mux_sel_X1hl    <= memex_mux_sel_X0hl;
      execute_mux_sel_X1hl  <= execute_mux_sel_X0hl;
      muldiv_mux_sel_X1hl   <= muldiv_mux_sel_X0hl;
      rfA_wen_X1hl          <= rfA_wen_X0hl;
      rfA_waddr_X1hl        <= rfA_waddr_X0hl;
      csr_wen_X1hl          <= csr_wen_X0hl;
      csr_addr_X1hl         <= csr_addr_X0hl;
      bubble_X1hl           <= bubble_next_X0hl;

      irB_X1hl              <= irB_X0hl;
      rfB_wen_X1hl          <= rfB_wen_X0hl;
      rfB_waddr_X1hl        <= rfB_waddr_X0hl;
      bubbleB_X1hl          <= bubbleB_next_X0hl;
    end
  end

  //----------------------------------------------------------------------
  // X1 Stage
  //----------------------------------------------------------------------

  // Is current stage valid?

  wire inst_val_X1hl = ( !bubble_X1hl && !squash_X1hl );

  // Dummy Squash Signal

  wire squash_X1hl = 1'b0;

  // Stall in X1 if memory response is not returned for a valid request

  wire stall_dmem_X1hl
    = ( !reset && dmemreq_val_X1hl && inst_val_X1hl && !dmemresp_val );


  assign dmemresp_rdy = !stall_X1hl;

  // Aggregate Stall Signal

  assign stall_X1hl = stall_dmem_X1hl;

  // Next bubble bit

  wire bubble_sel_X1hl   = ( squash_X1hl || stall_X1hl );
  wire bubble_next_X1hl  = ( !bubble_sel_X1hl ) ? bubble_X1hl
                         : ( bubble_sel_X1hl )  ? 1'b1
                         :                       1'bx;
  wire bubbleB_next_X1hl = ( !bubble_sel_X1hl ) ? bubbleB_X1hl
                         : ( bubble_sel_X1hl )  ? 1'b1
                         :                        1'bx;

  //----------------------------------------------------------------------
  // X2 <- X1
  //----------------------------------------------------------------------

  // FUA
  reg [31:0] irA_X2hl;
  reg        is_muldiv_X2hl;
  reg        rfA_wen_X2hl;
  reg  [4:0] rfA_waddr_X2hl;
  reg        csr_wen_X2hl;
  reg  [4:0] csr_addr_X2hl;
  reg        execute_mux_sel_X2hl;
  reg        muldiv_mux_sel_X2hl;
  reg        bubble_X2hl;

  // FUB
  reg [31:0] irB_X2hl;
  reg        rfB_wen_X2hl;
  reg  [4:0] rfB_waddr_X2hl;
  reg        bubbleB_X2hl;

  // Pipeline Controls

  always @ ( posedge clk ) begin
    if ( reset ) begin
      bubble_X2hl <= 1'b1;
      bubbleB_X2hl <= 1'b1;
    end
    else if( !stall_X2hl ) begin
      irA_X2hl              <= irA_X1hl;
      is_muldiv_X2hl        <= is_muldiv_X1hl;
      muldiv_mux_sel_X2hl   <= muldiv_mux_sel_X1hl;
      rfA_wen_X2hl          <= rfA_wen_X1hl;
      rfA_waddr_X2hl        <= rfA_waddr_X1hl;
      csr_wen_X2hl          <= csr_wen_X1hl;
      csr_addr_X2hl         <= csr_addr_X1hl;
      execute_mux_sel_X2hl  <= execute_mux_sel_X1hl;
      bubble_X2hl           <= bubble_next_X1hl;

      irB_X2hl              <= irB_X1hl;
      rfB_wen_X2hl          <= rfB_wen_X1hl;
      rfB_waddr_X2hl        <= rfB_waddr_X1hl;
      bubbleB_X2hl          <= bubbleB_next_X1hl;
    end
  end

  //----------------------------------------------------------------------
  // X2 Stage
  //----------------------------------------------------------------------

  // Is current stage valid?

  wire inst_val_X2hl = ( !bubble_X2hl && !squash_X2hl );

  // Dummy Squash Signal

  wire squash_X2hl = 1'b0;

  // Dummy Stall Signal

  assign stall_X2hl = 1'b0;

  // Next bubble bit

  wire bubble_sel_X2hl   = ( squash_X2hl || stall_X2hl );
  wire bubble_next_X2hl  = ( !bubble_sel_X2hl ) ? bubble_X2hl
                         : ( bubble_sel_X2hl )  ? 1'b1
                         :                       1'bx;
  wire bubbleB_next_X2hl = ( !bubble_sel_X2hl ) ? bubbleB_X2hl
                         : ( bubble_sel_X2hl )  ? 1'b1
                         :                        1'bx;

  //----------------------------------------------------------------------
  // X3 <- X2
  //----------------------------------------------------------------------

  // FUA
  reg [31:0] irA_X3hl;
  reg        is_muldiv_X3hl;
  reg        rfA_wen_X3hl;
  reg  [4:0] rfA_waddr_X3hl;
  reg        csr_wen_X3hl;
  reg  [4:0] csr_addr_X3hl;
  reg        bubble_X3hl;

  // FUB
  reg [31:0] irB_X3hl;
  reg        rfB_wen_X3hl;
  reg  [4:0] rfB_waddr_X3hl;
  reg        bubbleB_X3hl;

  // Pipeline Controls

  always @ ( posedge clk ) begin
    if ( reset ) begin
      bubble_X3hl <= 1'b1;
      bubbleB_X3hl <= 1'b1;
    end
    else if( !stall_X3hl ) begin
      irA_X3hl              <= irA_X2hl;
      is_muldiv_X3hl        <= is_muldiv_X2hl;
      muldiv_mux_sel_X3hl   <= muldiv_mux_sel_X2hl;
      rfA_wen_X3hl          <= rfA_wen_X2hl;
      rfA_waddr_X3hl        <= rfA_waddr_X2hl;
      csr_wen_X3hl          <= csr_wen_X2hl;
      csr_addr_X3hl         <= csr_addr_X2hl;
      execute_mux_sel_X3hl  <= execute_mux_sel_X2hl;
      bubble_X3hl           <= bubble_next_X2hl;

      irB_X3hl              <= irB_X2hl;
      rfB_wen_X3hl          <= rfB_wen_X2hl;
      rfB_waddr_X3hl        <= rfB_waddr_X2hl;
      bubbleB_X3hl          <= bubbleB_next_X2hl;
    end
  end

  //----------------------------------------------------------------------
  // X3 Stage
  //----------------------------------------------------------------------

  // Is current stage valid?

  wire inst_val_X3hl = ( !bubble_X3hl && !squash_X3hl );

  // Dummy Squash Signal

  wire squash_X3hl = 1'b0;

  // Dummy Stall Signal

  assign stall_X3hl = 1'b0;

  // Next bubble bit

  wire bubble_sel_X3hl   = ( squash_X3hl || stall_X3hl );
  wire bubble_next_X3hl  = ( !bubble_sel_X3hl ) ? bubble_X3hl
                         : ( bubble_sel_X3hl )  ? 1'b1
                         :                       1'bx;
  wire bubbleB_next_X3hl = ( !bubble_sel_X3hl ) ? bubbleB_X3hl
                         : ( bubble_sel_X3hl )  ? 1'b1
                         :                        1'bx;

  //----------------------------------------------------------------------
  // W <- X3
  //----------------------------------------------------------------------

  // FUA
  reg [31:0] irA_Whl;
  reg        rfA_wen_Whl;
  reg        csr_wen_Whl;
  reg  [4:0] csr_addr_Whl;
  reg        bubble_Whl;

  // FUB
  reg [31:0] irB_Whl;
  reg        rfB_wen_Whl;
  reg        bubbleB_Whl;

  // Pipeline Controls

  always @ ( posedge clk ) begin
    if ( reset ) begin
      bubble_Whl <= 1'b1;
      bubbleB_Whl <= 1'b1;
    end
    else if( !stall_Whl ) begin
      irA_Whl          <= irA_X3hl;
      rfA_wen_Whl      <= rfA_wen_X3hl;
      rfA_waddr_Whl    <= rfA_waddr_X3hl;
      csr_wen_Whl      <= csr_wen_X3hl;
      csr_addr_Whl     <= csr_addr_X3hl;
      bubble_Whl       <= bubble_next_X3hl;

      irB_Whl          <= irB_X3hl;
      rfB_wen_Whl      <= rfB_wen_X3hl;
      rfB_waddr_Whl    <= rfB_waddr_X3hl;
      bubbleB_Whl      <= bubbleB_next_X3hl;
    end
  end

  //----------------------------------------------------------------------
  // Writeback Stage
  //----------------------------------------------------------------------

  // Is current stage valid?

  wire inst_val_Whl = ( !bubble_Whl && !squash_Whl );
  wire instB_val_Whl = ( !bubbleB_Whl && !squash_Whl );

  // Only set register file wen if stage is valid

  assign rfA_wen_out_Whl = ( inst_val_Whl && !stall_Whl && rfA_wen_Whl );
  assign rfB_wen_out_Whl = ( instB_val_Whl && !stall_Whl && rfB_wen_Whl );

  // Dummy squash and stall signals

  wire squash_Whl = 1'b0;
  assign stall_Whl  = 1'b0;

  //----------------------------------------------------------------------
  // Debug registers for instruction disassembly
  //----------------------------------------------------------------------

  reg [31:0] irA_debug;
  reg [31:0] irB_debug;
  reg        inst_val_debug;

  always @ ( posedge clk ) begin
    irA_debug       <= irA_Whl;
    inst_val_debug  <= inst_val_Whl;
    irB_debug       <= irB_Whl;
  end

  //----------------------------------------------------------------------
  // CSR register
  //----------------------------------------------------------------------

  reg         csr_stats;

  always @ ( posedge clk ) begin
    if ( csr_wen_Whl && inst_val_Whl ) begin
      case ( csr_addr_Whl )
        12'd10 : csr_stats  <= proc2csr_data_Whl[0];
        12'd21 : csr_status <= proc2csr_data_Whl;
      endcase
    end
  end

//========================================================================
// Disassemble instructions
//========================================================================

  `ifndef SYNTHESIS

  riscv_InstMsgDisasm inst0_msg_disasm_D
  (
    .msg ( ir0_Dhl )
  );

  riscv_InstMsgDisasm instA_msg_disasm_X0
  (
    .msg ( irA_X0hl )
  );

  riscv_InstMsgDisasm instA_msg_disasm_X1
  (
    .msg ( irA_X1hl )
  );

  riscv_InstMsgDisasm instA_msg_disasm_X2
  (
    .msg ( irA_X2hl )
  );

  riscv_InstMsgDisasm instA_msg_disasm_X3
  (
    .msg ( irA_X3hl )
  );

  riscv_InstMsgDisasm instA_msg_disasm_W
  (
    .msg ( irA_Whl )
  );

  riscv_InstMsgDisasm instA_msg_disasm_debug
  (
    .msg ( irA_debug )
  );

  riscv_InstMsgDisasm inst1_msg_disasm_D
  (
    .msg ( ir1_Dhl )
  );

  riscv_InstMsgDisasm instB_msg_disasm_X0
  (
    .msg ( irB_X0hl )
  );

  riscv_InstMsgDisasm instB_msg_disasm_X1
  (
    .msg ( irB_X1hl )
  );

  riscv_InstMsgDisasm instB_msg_disasm_X2
  (
    .msg ( irB_X2hl )
  );

  riscv_InstMsgDisasm instB_msg_disasm_X3
  (
    .msg ( irB_X3hl )
  );

  riscv_InstMsgDisasm instB_msg_disasm_W
  (
    .msg ( irB_Whl )
  );

  riscv_InstMsgDisasm instB_msg_disasm_debug
  (
    .msg ( irB_debug )
  );

  `endif

//========================================================================
// Assertions
//========================================================================
// Detect illegal instructions and terminate the simulation if multiple
// illegal instructions are detected in succession.

  `ifndef SYNTHESIS

  reg overload = 1'b0;

  always @ ( posedge clk ) begin
    if (( !cs0[`RISCV_INST_MSG_INST_VAL] && !reset )
     || ( !cs1[`RISCV_INST_MSG_INST_VAL] && !reset )) begin
      $display(" RTL-ERROR : %m : Illegal instruction!");

      if ( overload == 1'b1 ) begin
        $finish;
      end

      overload = 1'b1;
    end
    else begin
      overload = 1'b0;
    end
  end

  `endif

endmodule

`endif

// vim: set textwidth=0 ts=2 sw=2 sts=2 :
